package stringmanipulation;

public class StringManipulation {
    public static String toUpperCase(String inp) {
        return inp.toUpperCase();
    }

    public static String toLowerCase(String inp) {
        return inp.toLowerCase();
    }

    public static String reverseString(String inp) {
        return new StringBuilder(inp).reverse().toString();
    }

}