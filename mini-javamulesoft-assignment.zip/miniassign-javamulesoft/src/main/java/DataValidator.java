import java.util.regex.Pattern;

public class DataValidator {

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return Pattern.matches(emailRegex, email);
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        // Assuming a 10-digit phone number format: XXXXXXXXXX
        String phoneRegex = "^[0-9]{10}$";
        return Pattern.matches(phoneRegex, phoneNumber);
    }

    public static boolean isValidCreditCard(String creditCardNumber) {
        // Assuming a 16-digit credit card number format: XXXX-XXXX-XXXX-XXXX
        String cardRegex = "^[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}$";
        return Pattern.matches(cardRegex, creditCardNumber);
    }
}
